# QuantaScript Syntax Guide

QuantaScript has a **simple, intuitive syntax** inspired by Python and Julia.

## 1. Variable Assignment
```quanta
energy = 10.5;
status = "active";
is_ready = True;
```

## 2. Functions & Namespaces
```quanta
energy = ZPE::compute_field(2.5e-9, "vacuum");
traffic = SmartCity::optimize_traffic(AI="neural_net", ZPE_boost=True);
```

## 3. Built-in Functions
- **ZPE::compute_field(fluctuation, medium="vacuum")** - Simulates zero-point energy fields.
- **SmartCity::optimize_traffic(AI="neural_net", ZPE_boost=True)** - AI-based traffic optimization.

## 4. Conditionals & Loops (Future Expansion)
```quanta
if energy > 5:
    print("High energy detected!");

for i in range(10):
    print(i);
```
