# QuantaScript Optimized Compiler

The QuantaScript Compiler translates high-level QuantaScript into **optimized bytecode**.

## Optimized Bytecode Instructions
- **STORE <variable> CONST <value>** - Assigns a constant value to a variable.
- **CALL <function> <args>** - Executes a built-in function efficiently.

## Optimized Compilation Example
Input QuantaScript:
```quanta
energy = ZPE::compute_field(3.2e-9, "vacuum");
```

Generated Optimized Bytecode:
```
STORE energy CALL ZPE::compute_field CONST 3.2e-9 "vacuum"
```
